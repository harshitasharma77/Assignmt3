package com.example.todoapp

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat

class ViewTodoActivity : AppCompatActivity() {

    private lateinit var todoDetailsTextView: TextView
    private val CHANNEL_ID = "todo_notification_channel"

    companion object {
        val loggedTodosList = mutableListOf<String>()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_todo)

        todoDetailsTextView = findViewById(R.id.todoDetailsTextView)

        val todoTitle = intent.getStringExtra("todoTitle")
        val todoDescription = intent.getStringExtra("todoDescription")

        if (todoTitle != null && todoDescription != null) {
            val todoDetails = "Title: $todoTitle\nDescription: $todoDescription"
            todoDetailsTextView.text = todoDetails

            // Add to the static list
            loggedTodosList.add(todoDetails)

            sendNotification(todoTitle, todoDescription)
        }
    }

    private fun sendNotification(todoTitle: String, todoDescription: String) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "To-Do Notifications",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Channel for to-do notifications"
            }
            notificationManager.createNotificationChannel(channel)
        }

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_todo) // Ensure you have this icon in your resources
            .setContentTitle("To-Do Added")
            .setContentText("Title: $todoTitle\nDescription: $todoDescription")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)

        notificationManager.notify(1, builder.build())
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.viewLoggedTodos -> {
                val intent = Intent(this, LoggedTodosActivity::class.java)
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}

