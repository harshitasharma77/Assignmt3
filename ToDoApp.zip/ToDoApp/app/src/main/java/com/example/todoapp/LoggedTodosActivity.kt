package com.example.todoapp

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity

class LoggedTodosActivity : AppCompatActivity() {

    private lateinit var loggedTodosListView: ListView
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_logged_todos)

        loggedTodosListView = findViewById(R.id.loggedTodosListView)

        adapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,
            ViewTodoActivity.loggedTodosList // Reference to the list in ViewTodoActivity
        )
        loggedTodosListView.adapter = adapter
    }
}
