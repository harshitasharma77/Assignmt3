package com.example.todoapp

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar

class MainActivity : AppCompatActivity() {

    private lateinit var todoTitleEditText: EditText
    private lateinit var todoDescriptionEditText: EditText
    private lateinit var addTodoButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        todoTitleEditText = findViewById(R.id.todoTitleEditText)
        todoDescriptionEditText = findViewById(R.id.todoDescriptionEditText)
        addTodoButton = findViewById(R.id.addTodoButton)

        addTodoButton.setOnClickListener {
            val todoTitle = todoTitleEditText.text.toString()
            val todoDescription = todoDescriptionEditText.text.toString()

            if (todoTitle.isNotEmpty() && todoDescription.isNotEmpty()) {
                // Passing data to ViewTodoActivity
                val intent = Intent(this, ViewTodoActivity::class.java).apply {
                    putExtra("todoTitle", todoTitle)
                    putExtra("todoDescription", todoDescription)
                }
                startActivity(intent)

                Toast.makeText(this, "To-Do item added", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Please enter both title and description", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.viewLoggedTodos -> {
                val intent = Intent(this, LoggedTodosActivity::class.java).apply {
                    putExtra("extraMessage", "Viewing Logged To-Dos")
                }
                startActivity(intent)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
